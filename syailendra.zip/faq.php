<?php $page = ('page0')?>
<?php include('inc_header.php');?>
	<section id="banner">			
		<img src="images/content/banner_disclaimer.jpg" alt=""/>
	</section>
	<section id="middle" class="page">
		<div class="box_orange"></div>
		<p class="space_top">space top</p>
		<div class="container">
			
			<div id="left_content">
				<ul class="breadcrumb">
					<li><a href="#">Home</a>&nbsp;/</li>
					<li><a href="#">FAQ</a></li>
				</ul>
				<h1>FAQ</h1>
				
				
				
				
				
				
				
				
			</div>
			
			
			<div id="right_content">
				<?php include('inc_contact_box.php');?>
				
			</div>
			
		</div>
	</section><!-- end middle --> 		
	
<?php include('inc_footer.php');?>



